document.addEventListener("DOMContentLoaded", () => {
  const productsContainer = document.querySelector(".products-container");

  const products = [
    { name: "Camiseta Básica", price: "$19.99", img: "assets/images/product1.jpg" },
    { name: "Jeans Slim", price: "$39.99", img: "assets/images/product2.jpg" },
    { name: "Chaqueta de Cuero", price: "$89.99", img: "assets/images/product3.jpg" },
    // Agregar más productos aquí
  ];

  products.forEach(product => {
    const productDiv = document.createElement("div");
    productDiv.classList.add("product-item");

    productDiv.innerHTML = `
      <img src="${product.img}" alt="${product.name}">
      <h3>${product.name}</h3>
      <p>${product.price}</p>
      <button class="add-to-cart">Añadir al carrito</button>
    `;

    productsContainer.appendChild(productDiv);
  });
});